from flask_app.config.mysqlconnection import connectToMySQL
from flask import flash

class Post:
    db_name = 'final_exam'

    def __init__(self,db_data):
        self.id = db_data['id']
        self.title = db_data['title']
        self.description = db_data['description']
        self.date = db_data['date']
        self.favorite = db_data['favorite']
        self.user_id = db_data['user_id']
        self.posted_by = ""

    @classmethod
    def save(cls,data):
        query = "INSERT INTO posts (title, description, date, favorite, user_id) VALUES (%(title)s,%(description)s,%(date)s,%(favorite)s,%(user_id)s);"
        return connectToMySQL(cls.db_name).query_db(query,data)

    @classmethod
    def get_all(cls):
        query = "SELECT * FROM posts JOIN users ON posts.user_id = users.id;"
        results = connectToMySQL(cls.db_name).query_db(query)
        all_posts = []
        for row in results:
            one_row = cls(row)
            one_row.posted_by = row ['first_name']
            all_posts.append(one_row)
        return all_posts

    @classmethod
    def get_one(cls, data):
        query = "SELECT * FROM posts WHERE id = %(id)s"
        results = connectToMySQL(cls.db_name).query_db(query, data)
        return cls(results[0])

    @classmethod
    def destroy(cls,data):
        query = "DELETE FROM posts WHERE id = %(id)s;"
        return connectToMySQL(cls.db_name).query_db(query, data)

    @classmethod
    def update(cls,data):
        query = "UPDATE posts SET title=%(title)s, description=%(description)s, date=%(date)s, favorite=%(favorite)s WHERE id = %(id)s "
        return connectToMySQL(cls.db_name).query_db(query,data)

    @staticmethod
    def validate_post(post):
        is_valid = True
        if len(post['title']) < 1:
            is_valid = False
            flash("The location must be at least 1 characters","post")
        if len(post['description']) < 3:
            is_valid = False
            flash("The description must be at least 3 characters","post")
        if post['date'] == "":
            is_valid = False
            flash("Please enter a date, post")
        return is_valid

